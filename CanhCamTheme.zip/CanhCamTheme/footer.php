</main>
<footer>
	footer
</footer>
</main>
<?php wp_footer() ?>
</body>
<script type="text/javascript" src="<?php echo bloginfo('template_directory') ?>/scripts/global.min.js"> </script>
<script type="text/javascript" src="<?php echo bloginfo('template_directory') ?>/scripts/swiper/swiper.min.js"> </script>
<script type="text/javascript" src="<?php echo bloginfo('template_directory') ?>/scripts/main.min.js?v=14.5.2"> </script>
</html>