<?php

return [
	'title' => __( 'Geolocation', 'it-l10n-ithemes-security-pro' ),
];
