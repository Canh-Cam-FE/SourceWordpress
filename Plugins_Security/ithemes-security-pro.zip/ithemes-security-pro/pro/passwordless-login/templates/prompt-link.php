<p class="itsec-pwls-login__link-wrap">
	<a class="itsec-pwls-login__link" href="<?php echo esc_url( $prompt_link ); ?>">
		<?php esc_html_e( 'Email Magic Link', 'it-l10n-ithemes-security-pro' ) ?>
	</a>
</p>
