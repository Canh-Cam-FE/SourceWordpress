<div class="itsec-pwls-login-fallback__or">
	<span><?php esc_html_e( 'Or', 'it-l10n-ithemes-security-pro' ) ?></span>
</div>
