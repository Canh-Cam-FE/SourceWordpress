export { default as AdminBar } from './admin-bar';
