(function($) {
 $("#dbprefix_form").validate();
})(jQuery);