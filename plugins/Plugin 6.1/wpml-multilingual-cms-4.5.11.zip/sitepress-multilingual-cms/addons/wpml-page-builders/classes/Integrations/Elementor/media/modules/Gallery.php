<?php

namespace WPML\PB\Elementor\Media\Modules;

class Gallery extends \WPML_Elementor_Media_Node_With_Images_Property {
	protected function get_property_name() {
		return 'gallery';
	}
}