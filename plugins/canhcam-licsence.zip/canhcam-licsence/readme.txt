=== Advanced Custom Fields Pro ===
Contributors: canhcam
Tags: license
Requires at least: 4.7
Tested up to: 6.1.1
Requires PHP: 5.6
Stable tag: 6.0.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html