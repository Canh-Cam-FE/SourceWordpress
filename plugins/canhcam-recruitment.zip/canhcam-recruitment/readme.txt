﻿/*
* Plugin Module Tuyển dụng
* Author: https://canhcam.vn
*/

== Những thay đổi ==

= V1.0.0 - 30/11/2022 =
* Ra mắt plugin